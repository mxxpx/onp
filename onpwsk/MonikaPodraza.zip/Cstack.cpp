#include "Cstack.h"
#include <stdlib.h>

typedef struct CStack
{
    char value;
    CStack* next;
} ;            

CStack* head = NULL;

void push(char c)
{
    CStack* x = (CStack*)malloc(sizeof(CStack));
    if (!x)
    {
        perror("Allocation error!");
        return;
    }
    x->value = c;
    x->next = head;
    head = x;
}

void emptyStack()
{
    while (!isEmpty())
        del();
}

void del()
{
    if (isEmpty())
    {
        perror("Stack underflow!");
        return;
    }
    CStack* temp = head;
    head = temp->next;
    free(temp);
}

char top()
{
    if (isEmpty())
        return 0;
    return head->value;
}

char pop()
{
    char c;
    if (c = top())
    {
        del();
        return c;
    }
    perror("Stack underflow");
    return 0;
}

int isEmpty()
{
    return !head;
}