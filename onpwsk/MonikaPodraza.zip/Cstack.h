#ifndef STACK_H  
#define STACK_H

typedef struct CStack;

void emptyStack();
void push(char c);
char pop();
char top();
void del();
int isEmpty();


#endif 