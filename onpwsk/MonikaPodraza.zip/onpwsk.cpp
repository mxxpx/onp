﻿// onpwsk.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//
#include <iostream>
#include <stdio.h>
#include "Cstack.h"
#include "Dstack.h"

#define DOT '.'

using namespace std;

int prior(char c);
int isOper(char c);
int isDigit(char c);
void skipSpaces();
double getNUm();
char getOper();
void onp();


int main()
{
    cout << "Podaj wyrazenie:" << endl;
    onp();
}

int prior(char c) 
{
    switch (c) 
    {
    case '+':
    case '-':
        return 1;
    case '*':
    case '/':
        return 2;
    case '^':
        return 3;
    }
    return 0;
}

int isOper(char c)
{
    switch (c) 
    {
    case '+':
    case '-':
    case '*':
    case '/':
    case '^':
        return 1;
    }
    return 0;
}

int isDigit(char c) //sprawdza czy jest cyfrą
{
    return (c >= '0' && c <= '9');
}


void skipSpaces() 
{
    char c;
    while ((c = getchar()) == ' ');
    //while( isspace(c = getchar()))
    ungetc(c, stdin);
}

double getNUm()
{
    char c;
    double res = 0;
    int sign = 0;
    skipSpaces();

    if ((c = getchar()) == '-')
        sign = 1;
    else if (c != '+') ungetc(c, stdin);

    while (isDigit(c = getchar()))
        res = res * 10 + (c - '0');

    if (c == DOT)
    {
        double coef = 0.1;
        while (isDigit(c = getchar()))
        {
            res += (c - '0') * coef;
            coef *= 0.1;
        }

    }

    if (sign) res = -res;

    return res;
}

char getOper() 
{
    skipSpaces();
    return getchar();
}


void onp() 
{
    char c;
    while ((c = getchar()) != '\n') 
    {
        if (!isOper(c)) {
            putchar(c);
        }
        else {
            while (prior(c) <= prior(top())) {
                putchar(pop());
            }
            push(c);

        }
    }
    
    while (!isEmpty())
        putchar(pop());
}

