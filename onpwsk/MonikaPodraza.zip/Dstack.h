#ifndef DSTACK_H 
#define DSTACK H 
#include "float.h"

typedef struct DStack;

void demptyStack();
void dpush(double c);
double dpop();
double dtop();
void ddel();
int disEmpty();


#endif 

