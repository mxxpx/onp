#include "Dstack.h"
#include <stdlib.h>

typedef struct DStack
{
    double value;
    DStack* next;
};

DStack* dhead = NULL;

void dpush(double c)
{
    DStack* x = (DStack*)malloc(sizeof(DStack));
    if (!x)
    {
        perror("Allocation error!");
        return;
    }
    x->value = c;
    x->next = dhead;
    dhead = x;
}

void demptyStack()
{
    while (!disEmpty())
        ddel();
}

void ddel()
{
    if (disEmpty())
    {
        perror("Stack underflow!");
        return;
    }
    DStack* temp = dhead;
    dhead = temp->next;
    free(temp);
}

double dtop()
{
    if (disEmpty())
        return DBL_MIN;
    return dhead->value;
}

double dpop()
{
    double c;
    if (c = dtop())
    {
        ddel();
        return c;
    }
    perror("Stack underflow");
    return DBL_MIN;
}

int disEmpty()
{
    return !dhead;
}


